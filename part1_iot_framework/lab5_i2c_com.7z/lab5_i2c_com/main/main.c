#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * @brief Starting point function
 * 
 */

void app_main(void) {

	printf("Hello ESP32 !\n");
	
}
